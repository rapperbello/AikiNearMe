// Firebase Cloud Functions starter for secure Paystack verification.
// This file is a server-side reference; deploy only after installing dependencies
// and configuring PAYSTACK_SECRET_KEY with Firebase Secret Manager.
// Never put PAYSTACK_SECRET_KEY in frontend files.
const { onRequest } = require("firebase-functions/v2/https");
const { defineSecret } = require("firebase-functions/params");
const admin = require("firebase-admin");
const crypto = require("crypto");
const PAYSTACK_SECRET_KEY = defineSecret("PAYSTACK_SECRET_KEY");
admin.initializeApp();

// Example webhook endpoint. Paystack sends x-paystack-signature; verify the HMAC
// before trusting the event. This starter intentionally does not activate a plan
// until your Firestore schema, ownership checks and idempotency rules are configured.
exports.paystackWebhook = onRequest({secrets:[PAYSTACK_SECRET_KEY]}, async (req,res)=>{
  if(req.method!=="POST") return res.status(405).send("Method not allowed");
  const signature=req.get("x-paystack-signature");
  const raw=JSON.stringify(req.body);
  const expected=crypto.createHmac("sha512",PAYSTACK_SECRET_KEY.value()).update(raw).digest("hex");
  if(!signature || !crypto.timingSafeEqual(Buffer.from(signature),Buffer.from(expected))) {
    return res.status(401).send("Invalid signature");
  }
  const event=req.body?.event;
  const reference=req.body?.data?.reference;
  if(event==="charge.success" && reference) {
    // TODO: verify reference directly with Paystack API from this backend.
    // TODO: check amount, currency, account ownership, plan, expiry and idempotency.
    // TODO: only then update the authenticated user's subscription in Firestore.
    console.log("Signed success webhook received; reference requires API verification:", reference);
  }
  return res.status(200).send("Webhook received");
});